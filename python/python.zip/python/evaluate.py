"""evaluate.py — score a trained cell classifier on held-out synthetic frames.

train.py prints two numbers as it goes. This script is the fuller picture:
it regenerates a FRESH set of synthetic frames (a different seed, so nothing
the model saw during training), and reports the metrics that actually decide
whether the shortlist is useful to the pattern matcher downstream.

Metrics
-------
top-k recall      fraction of frames where at least one truly-visible cell is
                  among the model's k highest-scoring cells
coverage@k        fraction of ALL visible cells captured in the top k
                  (averaged over frames) -- top-k recall only asks for one hit
threshold recall  same as top-k recall but for the operational rule the flight
                  code actually uses: every cell with p > thr
shortlist size    mean number of cells above thr, out of 529
reduction         529 / shortlist size -- how much the search space shrank
random baseline   the same metric for a shortlist drawn uniformly at random,
                  which is the only honest way to read the numbers above

Run (after make_dataset.py and train.py):
  python3 evaluate.py --n 5000 --seed 999
"""

import argparse
import os
import numpy as np

import st_features as F
from st_cells import vectors_to_cells, NUM_CELLS
from st_catalog import Catalog
from st_sim import NoiseModel, simulate_frame
from make_dataset import frame_cells

IMG_W, IMG_H = 1280, 960
GEN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "gen")


def forward(m, X):
    """NumPy forward pass, identical to train.py's MLP.predict()."""
    x = (X - m["in_mean"]) / np.where(m["in_scale"] == 0, 1, m["in_scale"])
    h1 = np.maximum(x @ m["W1"].T + m["b1"], 0.0)
    h2 = np.maximum(h1 @ m["W2"].T + m["b2"], 0.0)
    z = h2 @ m["W3"].T + m["b3"]
    out = np.empty_like(z)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    e = np.exp(z[~pos])
    out[~pos] = e / (1.0 + e)
    return out


def build_eval_set(n, seed, fx=1800.0, catalog=None):
    """Fresh frames the model has never seen, using the TRAINED bin edges."""
    cos_edges = np.load(os.path.join(GEN, "bins.npy")).astype(np.float32)
    cam = F.Camera(fx=fx, fy=fx, cx=IMG_W / 2.0, cy=IMG_H / 2.0)
    cat = Catalog.load(catalog)
    rng = np.random.default_rng(seed)
    noise = NoiseModel()

    X = np.zeros((n, F.NUM_BINS), dtype=np.float32)
    Y = np.zeros((n, NUM_CELLS), dtype=np.float32)
    kept = 0
    for _ in range(n):
        fr = simulate_frame(cat, cam, IMG_W, IMG_H, rng, noise)
        if len(fr["uv"]) < 4:
            continue
        uv, _ = F.select_brightest(fr["uv"], fr["flux"])
        h = F.histogram(cam.pixels_to_vectors(uv), cos_edges)
        if h is None:
            continue
        X[kept] = h
        Y[kept, frame_cells(cam, fr["R"], IMG_W, IMG_H)] = 1.0
        kept += 1
    return X[:kept], Y[:kept]


def random_baseline_topk(Y, k, rng):
    """P(at least one visible cell in k uniformly random cells), per frame.

    Computed in closed form rather than sampled: with v visible cells out of
    N, the chance k random picks all miss is C(N-v, k) / C(N, k).
    """
    v = Y.sum(1).astype(int)
    N = Y.shape[1]
    miss = np.ones(len(v))
    for i in range(k):
        miss *= np.maximum(N - v - i, 0) / (N - i)
    return float((1.0 - miss).mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=5000, help="eval frames")
    ap.add_argument("--seed", type=int, default=999, help="MUST differ from training seed")
    ap.add_argument("--thr", type=float, default=0.15, help="accept threshold")
    ap.add_argument("--fx", type=float, default=1800.0,
                help="MUST match the focal length make_dataset.py used")
    ap.add_argument("--catalog", default=None)
    args = ap.parse_args()

    model = dict(np.load(os.path.join(GEN, "model.npz")))
    X, Y = build_eval_set(args.n, args.seed, fx=args.fx, catalog=args.catalog)
    P = forward(model, X.astype(np.float64))
    rng = np.random.default_rng(0)

    print(f"eval frames: {len(X)}  (seed {args.seed}, unseen in training)")
    print(f"visible cells per frame: mean {Y.sum(1).mean():.1f}, "
          f"min {Y.sum(1).min():.0f}, max {Y.sum(1).max():.0f} of {NUM_CELLS}")
    print(f"catalog: {'Hipparcos CSV' if args.catalog else 'SYNTHETIC PLACEHOLDER (uniform sky)'}")

    # Two baselines, because the two metrics have different chance levels and
    # comparing a metric against the wrong one is how a mediocre model looks
    # good. For coverage, k random picks capture k/N of the visible cells on
    # average, whatever v is.
    print("\n  k   top-k recall  (random)   coverage@k  (random)   precision@k")
    for k in (1, 4, 8, 16, 32, 64):
        top = np.argsort(-P, axis=1)[:, :k]
        got = np.take_along_axis(Y, top, axis=1)
        recall = float(got.max(axis=1).mean())
        coverage = float((got.sum(1) / np.maximum(Y.sum(1), 1)).mean())
        precision = float((got.sum(1) / k).mean())
        base_r = random_baseline_topk(Y, k, rng)
        base_c = k / NUM_CELLS
        print(f"{k:3d}   {recall:11.3f}  {base_r:8.3f}   {coverage:10.3f}  "
              f"{base_c:8.3f}   {precision:11.3f}")

    print("\noperational threshold rule (p > thr):")
    for thr in (0.05, 0.10, 0.15, 0.30, 0.50):
        sel = P > thr
        size = sel.sum(1)
        hit = (sel & (Y > 0)).any(axis=1)
        cov = ((sel & (Y > 0)).sum(1) / np.maximum(Y.sum(1), 1))
        empty = float((size == 0).mean())
        print(f"  thr {thr:.2f}   shortlist {size.mean():6.1f}/{NUM_CELLS}  "
              f"({NUM_CELLS / max(size.mean(), 1e-9):5.1f}x reduction)  "
              f"hit {hit.mean():.3f}  coverage {cov.mean():.3f}  "
              f"empty {empty:.3f}"
              + ("   <-- default" if abs(thr - args.thr) < 1e-9 else ""))

    # Per-cell balance: a model that is excellent on average can still be
    # useless over particular patches of sky, which is a lost-in-space failure.
    top8 = np.argsort(-P, axis=1)[:, :8]
    hit8 = np.take_along_axis(Y, top8, axis=1).max(axis=1)
    print(f"\nworst-case check: top-8 recall on the 10% of frames with the "
          f"fewest stars = "
          f"{float(hit8[np.argsort(X.sum(1))[:len(X)//10]].mean()):.3f}")


if __name__ == "__main__":
    main()
