"""sweep_fov.py — find a field of view / partition size pair that poses a
question worth asking.

The problem this solves
-----------------------
529 equal-area cells are about 9 degrees across. At fx = 1800 px the frame is
39.1 x 29.9 degrees, so roughly 24 cells fall inside it. A classifier asked
"which cells are in view?" under those conditions can answer "about two dozen"
and be right almost always, and the shortlist it produces cannot be shorter
than the number of cells the frame genuinely covers. The metric looks good and
the search space barely shrinks.

The fix is geometric, not statistical: either narrow the field of view (raise
fx) or coarsen the partition (lower N) until a frame covers a small number of
cells. This script sweeps both and reports, for each configuration, what the
pattern matcher downstream actually cares about.

The figure of merit
-------------------
Search-space reduction, not recall. Triangle matching cost grows with the
SQUARE of the number of catalog stars searched, because every star pairs with
every other. If the shortlist covers a fraction f of the sky, candidate pairs
shrink by about f^2. A shortlist of 32/529 cells (f = 6.1%) is a 270x pair
reduction; a shortlist of 3/200 (f = 1.5%) is 4400x. Recall must stay high, but
recall alone is not the goal.

Run:
  python3 sweep_fov.py                 # default 5 configurations
  python3 sweep_fov.py --n 40000       # more training data per configuration
"""

import argparse
import json
import math
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
IMG_W, IMG_H = 1280, 960

# (label, focal length px, partition size)
CONFIGS = [
    ("baseline",        1800,  529),   # as shipped: ~24 cells in view
    ("coarsen only",    1800,   92),   # keep the lens, enlarge the cells
    ("narrow only",     4000,  529),   # keep the partition, narrow the lens
    ("narrow + coarse", 4000,  200),   # both, moderately
    ("tight",           6000,  529),   # CubeSat-class 15 deg field of view
]


def geometry(fx, n_cells):
    """Analytic field of view and the sky fraction one cell covers."""
    a = math.atan(IMG_W / 2.0 / fx)
    b = math.atan(IMG_H / 2.0 / fx)
    sr = 4.0 * math.asin(math.sin(a) * math.sin(b))
    diag = 2.0 * math.degrees(math.atan(math.hypot(IMG_W / 2.0 / fx,
                                                   IMG_H / 2.0 / fx)))
    cell_deg = math.degrees(math.sqrt(4.0 * math.pi / n_cells))
    return diag, sr, sr / (4.0 * math.pi), cell_deg


def run(cmd, env):
    p = subprocess.run([sys.executable] + cmd, cwd=HERE, env=env,
                       capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"{cmd} failed:\n{p.stderr[-2000:]}")
    return p.stdout


def grab(text, pattern, cast=float):
    m = re.search(pattern, text)
    return cast(m.group(1)) if m else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=20000, help="training frames")
    ap.add_argument("--eval-n", type=int, default=5000)
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--thr", type=float, default=0.15)
    ap.add_argument("--catalog", default=None)
    args = ap.parse_args()

    rows = []
    for label, fx, n_cells in CONFIGS:
        diag, sr, frac, cell_deg = geometry(fx, n_cells)
        print(f"\n=== {label}: fx={fx}, {n_cells} cells "
              f"({diag:.1f} deg diagonal, {cell_deg:.1f} deg cells) ===",
              flush=True)

        env = dict(os.environ, ST_NUM_CELLS=str(n_cells))
        cmd_cat = ["--catalog", args.catalog] if args.catalog else []

        out_d = run(["make_dataset.py", "--n", str(args.n),
                     "--fx", str(fx), "--seed", "1"] + cmd_cat, env)
        in_view = grab(out_d, r"labels per frame: mean ([\d.]+)")
        unseen = grab(out_d, r"cells never seen: (\d+)", int)

        out_t = run(["train.py", "--epochs", str(args.epochs)], env)
        print(out_t.strip().splitlines()[-2], flush=True)

        out_e = run(["evaluate.py", "--n", str(args.eval_n), "--seed", "999",
                     "--fx", str(fx), "--thr", str(args.thr)] + cmd_cat, env)

        # Pull the k=8 row and the default-threshold row out of the report.
        m8 = re.search(r"^\s*8\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)",
                       out_e, re.M)
        top8, rand8, _, _, prec8 = (float(x) for x in m8.groups())
        mt = re.search(rf"thr {args.thr:.2f}\s+shortlist\s+([\d.]+)/\d+.*?"
                       r"hit ([\d.]+)\s+coverage ([\d.]+)", out_e)
        short, hit, cov = (float(x) for x in mt.groups())

        f_short = short / n_cells                  # sky fraction of shortlist
        star_red = 1.0 / f_short                   # fewer catalog stars
        pair_red = 1.0 / (f_short ** 2)            # fewer candidate pairs
        pair_ideal = 1.0 / (frac ** 2)             # perfect-oracle ceiling

        rows.append(dict(label=label, fx=fx, cells=n_cells, diag=diag,
                         cell_deg=cell_deg, in_view=in_view, unseen=unseen,
                         top8=top8, rand8=rand8, prec8=prec8, short=short,
                         hit=hit, cov=cov, star_red=star_red,
                         pair_red=pair_red, pair_ideal=pair_ideal,
                         eff=pair_red / pair_ideal))

    print("\n" + "=" * 104)
    print(f"{'configuration':17s} {'fx':>5s} {'cells':>6s} {'FOV':>6s} "
          f"{'in view':>8s} {'top-8':>6s} {'prec@8':>7s} {'shortlist':>10s} "
          f"{'hit':>6s} {'stars':>7s} {'pairs':>9s} {'of max':>7s}")
    print("-" * 104)
    for r in rows:
        print(f"{r['label']:17s} {r['fx']:5d} {r['cells']:6d} "
              f"{r['diag']:5.1f}d {r['in_view']:8.1f} {r['top8']:6.3f} "
              f"{r['prec8']:7.3f} {r['short']:6.1f}/{r['cells']:<3d} "
              f"{r['hit']:6.3f} {r['star_red']:6.1f}x {r['pair_red']:8.0f}x "
              f"{100 * r['eff']:6.1f}%")
    print("-" * 104)
    print("in view    : mean cells the frame actually covers (the floor on shortlist length)")
    print("top-8/hit  : at least one truly-visible cell in the top 8 / above threshold")
    print("stars,pairs: catalog search reduction from the shortlist; pairs ~ stars^2")
    print("of max     : pair reduction as a percentage of the perfect-oracle ceiling")

    with open(os.path.join(HERE, "..", "gen", "sweep.json"), "w") as f:
        json.dump(rows, f, indent=2)


if __name__ == "__main__":
    main()
